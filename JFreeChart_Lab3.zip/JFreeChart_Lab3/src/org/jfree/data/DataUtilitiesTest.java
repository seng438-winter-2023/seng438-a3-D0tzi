package org.jfree.data;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;
import java.util.Arrays;

import org.junit.*;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Test;

public class DataUtilitiesTest extends DataUtilities {

	private Mockery mockingContext;
	private Values2D values;
	private KeyedValues kValues;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {}
	
	@Before
	public void setUp() throws Exception {
		mockingContext = new Mockery();
		values = mockingContext.mock(Values2D.class);
		kValues = mockingContext.mock(KeyedValues.class);
	}
	
	@Test
	public void calculateColumnTotalForFourPositiveValues() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(3.0));
				one(values).getValue(1, 0);
				will(returnValue(2.5));
				one(values).getValue(2, 0);
				will(returnValue(7.0));
				one(values).getValue(3, 0);
				will(returnValue(10.5));
			}
		});
		
		double result = DataUtilities.calculateColumnTotal(values, 0);
		
		assertEquals("Result should equal 23.0", 23.0, result, .000000001d);
	}
	
	@Test
	public void calculateColumnTotalForFourNegativeValues() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(-1.0));
				one(values).getValue(1, 0);
				will(returnValue(-2.5));
				one(values).getValue(2, 0);
				will(returnValue(-7.0));
				one(values).getValue(3, 0);
				will(returnValue(-14.5));
			}
		});
		
		double result = DataUtilities.calculateColumnTotal(values, 0);
		
		assertEquals("Result should equal -25.0", -25.0, result, .000000001d);
	}
	
	@Test(expected = InvalidParameterException.class)
	public void exceptionThrownOnInvalidDataColumn() {
		DataUtilities.calculateColumnTotal(null, 0);
	}
	
	@Test
	public void calculateColumnTotalForFourPositiveValuesValid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(3.0));
				one(values).getValue(1, 0);
				will(returnValue(2.5));
				one(values).getValue(2, 0);
				will(returnValue(7.0));
				one(values).getValue(3, 0);
				will(returnValue(10.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateColumnTotal(values, 0, i);
		
		assertEquals("Result should equal 23.0", 23.0, result, .000000001d);
	}
	
	@Test
	public void calculateColumnTotalForFourNegativeValuesValid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(-1.0));
				one(values).getValue(1, 0);
				will(returnValue(-2.5));
				one(values).getValue(2, 0);
				will(returnValue(-7.0));
				one(values).getValue(3, 0);
				will(returnValue(-14.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateColumnTotal(values, 0, i);
		
		assertEquals("Result should equal -25.0", -25.0, result, .000000001d);
	}
	
	@Test
	public void calculateColumnTotalRowCountInvalid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(0));
				one(values).getValue(0, 0);
				will(returnValue(3.0));
				one(values).getValue(1, 0);
				will(returnValue(2.5));
				one(values).getValue(2, 0);
				will(returnValue(7.0));
				one(values).getValue(3, 0);
				will(returnValue(10.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateColumnTotal(values, 0, i);
		
		assertEquals("Result should equal 0.0", 0.0, result, .000000001d);
	}
	
	@Test
	public void calculateRowTotalForFourPositiveValues() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getColumnCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(3.5));
				one(values).getValue(0, 1);
				will(returnValue(2.0));
				one(values).getValue(0, 2);
				will(returnValue(7.5));
				one(values).getValue(0, 3);
				will(returnValue(15.0));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(values, 0);
		
		assertEquals("Result should equal 28.0", 28.0, result, .000000001d);
	}
	
	@Test
	public void calculateRowTotalForFourNegativeValues() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getColumnCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(-2.5));
				one(values).getValue(0, 1);
				will(returnValue(-5.5));
				one(values).getValue(0, 2);
				will(returnValue(-7.5));
				one(values).getValue(0, 3);
				will(returnValue(-15.0));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(values, 0);
		
		assertEquals("Result should equal -30.5", -30.5, result, .000000001d);
	}
	
	
	@Test(expected = InvalidParameterException.class)
	public void exceptionThrownOnInvalidDataRow() {
		DataUtilities.calculateRowTotal(null, 0);
	}
	
	@Test
	public void calculateRowTotalForFourPositiveValuesValid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getColumnCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(3.0));
				one(values).getValue(0, 1);
				will(returnValue(2.5));
				one(values).getValue(0, 2);
				will(returnValue(7.0));
				one(values).getValue(0, 3);
				will(returnValue(10.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateRowTotal(values, 0, i);
		
		assertEquals("Result should equal 23.0", 23.0, result, .000000001d);
	}
	
	@Test
	public void calculateRowTotalForFourNegativeValuesValid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getColumnCount();
				will(returnValue(4));
				one(values).getValue(0, 0);
				will(returnValue(-1.0));
				one(values).getValue(0, 1);
				will(returnValue(-2.5));
				one(values).getValue(0, 2);
				will(returnValue(-7.0));
				one(values).getValue(0, 3);
				will(returnValue(-14.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateRowTotal(values, 0, i);
		
		assertEquals("Result should equal -25.0", -25.0, result, .000000001d);
	}
	
	@Test
	public void calculateRowTotalColumnCountInvalid() {
		mockingContext.checking(new Expectations() {
			{
				one(values).getColumnCount();
				will(returnValue(0));
				one(values).getValue(0, 0);
				will(returnValue(3.0));
				one(values).getValue(1, 0);
				will(returnValue(2.5));
				one(values).getValue(2, 0);
				will(returnValue(7.0));
				one(values).getValue(3, 0);
				will(returnValue(10.5));
			}
		});
		
		int[] i = {0, 1, 2, 3};
		
		double result = DataUtilities.calculateRowTotal(values, 0, i);
		
		assertEquals("Result should equal 0.0", 0.0, result, .000000001d);
	}
	
	@Test
	public void createEmptyNumberArray() {
		double[] data = {};
		
		Number[] result = DataUtilities.createNumberArray(data);
		Number[] expected = {};
		
		assertTrue("Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test
	public void createNumberArrayPositiveValues() {
		double[] data = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		Number[] result = DataUtilities.createNumberArray(data);
		Number[] expected = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		assertTrue("Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test
	public void createNumberArrayNegativeValues() {
		double[] data = {-1.0, -2.0, -3.0, -4.0, -5.0};
		
		Number[] result = DataUtilities.createNumberArray(data);
		Number[] expected = {-1.0, -2.0, -3.0, -4.0, -5.0};
		
		assertTrue("Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test
	public void createEmpty2DNumberArray() {
		double[][] data = {};
		
		Number[][] result = DataUtilities.createNumberArray2D(data);
		Number[][] expected = {};
		
		assertTrue("2D Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test
	public void create2DNumberArrayPositiveValues() {
		double[][] data = {{1.0, 2.0, 3.0, 4.0, 5.0}, {6.0, 7.0, 8.0}, {1.0}};
		
		Number[][] result = DataUtilities.createNumberArray2D(data);
		Number[][] expected = {{1.0, 2.0, 3.0, 4.0, 5.0}, {6.0, 7.0, 8.0}, {1.0}};
		
		assertTrue("2D Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test
	public void create2DNumberArrayNegativeValues() {
		double[][] data = {{-1.0, -2.0, -3.0, -4.0, -5.0}, {-6.0, -7.0, -8.0}, {-1.0}};
		
		Number[][] result = DataUtilities.createNumberArray2D(data);
		Number[][] expected = {{-1.0, -2.0, -3.0, -4.0, -5.0}, {-6.0, -7.0, -8.0}, {-1.0}};
		
		assertTrue("2D Number array created with incorrect values", Arrays.equals(expected, result));
	}
	
	@Test(expected = InvalidParameterException.class)
	public void exceptionThrownOnInvalidPercentageData() {
		DataUtilities.getCumulativePercentages(null);
	}
	
	@Test
	public void cumulatePercentageForZeroValueKeyPairs() {
		final int KEY_AMOUNT = 3;
		mockingContext.checking(new Expectations() {
			{
				String[] names = {"Key1", "Key2", "Key3"};
				double[] values = {0, 0, 0};
				for (int i = 0; i < KEY_AMOUNT; i++) {
					allowing(kValues).getValue(i);
					will(returnValue(values[i]));
					allowing(kValues).getKey(i);
					will(returnValue(names[i]));
				}
				allowing(kValues).getItemCount();
				will(returnValue(KEY_AMOUNT));
				allowing(kValues).getKeys();
				will(returnEnumeration(Arrays.asList(names)));
			}
		});
		
		KeyedValues result = DataUtilities.getCumulativePercentages(kValues);
		for (int i = 1; i < KEY_AMOUNT + 1; i++) {
			assertEquals("Result should be NaN, due to a division by zero", Double.NaN, result.getValue("Key" + i));
		}
	}
	
	@Test 
	public void cumulatePercentageForPositiveValueKeyPairs() {
		mockingContext.checking(new Expectations() {
			{
				final int KEY_AMOUNT = 3;
				String[] names = {"KeyOne", "KeyTwo", "KeyThree"};
				double[] values = {5.0, 9.0, 2.0};
				for (int i = 0; i < KEY_AMOUNT; i++) {
					allowing(kValues).getValue(i);
					will(returnValue(values[i]));
					allowing(kValues).getKey(i);
					will(returnValue(names[i]));
				}
				allowing(kValues).getItemCount();
				will(returnValue(KEY_AMOUNT));
				allowing(kValues).getKeys();
				will(returnEnumeration(Arrays.asList(names)));
			}
		});
		
		KeyedValues result = DataUtilities.getCumulativePercentages(kValues);
		assertEquals("Result should equal 0.3125", 0.3125, result.getValue("KeyOne").doubleValue(), .000000001d);
	}
	
	@Test 
	public void cumulatePercentageForNegativeValueKeyPairs() {
		mockingContext.checking(new Expectations() {
			{
				final int KEY_AMOUNT = 3;
				String[] names = {"KeyOne", "KeyTwo", "KeyThree"};
				double[] values = {-5.0, -9.0, -2.0};
				for (int i = 0; i < KEY_AMOUNT; i++) {
					allowing(kValues).getValue(i);
					will(returnValue(values[i]));
					allowing(kValues).getKey(i);
					will(returnValue(names[i]));
				}
				allowing(kValues).getItemCount();
				will(returnValue(KEY_AMOUNT));
				allowing(kValues).getKeys();
				will(returnEnumeration(Arrays.asList(names)));
			}
		});
		
		KeyedValues result = DataUtilities.getCumulativePercentages(kValues);
		assertEquals("Result should equal 0.3125", 0.3125, result.getValue("KeyOne").doubleValue(), .000000001d);
	}
	
	@Test
	public void equalWhenOnlyANull() {
		assertFalse("Result should be false", equal(null, new double[5][5]));
	}
	
	@Test
	public void equalWhenOnlyBNull() {
		assertFalse("Result should be false", equal(new double[5][5], null));
	}
	
	@Test
	public void equalWhenBothNull() {
		assertTrue("Result should be true", equal(null, null));
	}
	
	@Test
	public void equalWhenBothEqual() {
		assertTrue("Result should be true", equal(new double[5][5], new double[5][5]));
	}
	
	@Test
	public void equalWhenLengthNotEqual() {
		assertFalse("Result should be false", equal(new double[4][5], new double[5][5]));
	}
	
	@Test
	public void equalWhenLengthEqualButValueNot() {
		double[][] d = {{5.0}};
		double[][] e = {{2.0}};
		assertFalse("Result should be false", equal(d, e));
	}
	
	@Test
	public void cloneClonesProperlyOnPositiveValue() {
		double[][] original = {{1.0}};
		double[][] cloned = clone(original);
		assertEquals("Cloned array contains array with 1.0.", original[0][0], cloned[0][0], .000000001d);
	}
	
	@Test
	public void cloneClonesProperlyOnNegativeValue() {
		double[][] original = {{-1.0}};
		double[][] cloned = clone(original);
		assertEquals("Cloned array contains array with -1.0.", original[0][0], cloned[0][0], .000000001d);
	}
	
	@After
    public void tearDown() throws Exception {}

    @AfterClass
    public static void tearDownAfterClass() throws Exception {}
	
	

}
